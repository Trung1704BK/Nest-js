export class CreateSeedDto {}
