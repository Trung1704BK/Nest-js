import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './users/users.module';
import { ReportsModule } from './reports/reports.module';
import { User } from './users/user.entity';
import { Report } from './reports/report.entity';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost', // Thay đổi thành địa chỉ host MySQL của bạn
      port: 3306, // Thay đổi nếu cần
      username: 'root', // Thay đổi tên người dùng MySQL của bạn
      password: '123456789', // Thay đổi mật khẩu MySQL của bạn
      database: 'account_user', // Thay đổi tên cơ sở dữ liệu của bạn
      entities: [User, Report],
      synchronize: true,
    }),
    UsersModule,
    ReportsModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
