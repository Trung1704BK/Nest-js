-- AlterTable
ALTER TABLE `users` MODIFY `birthAt` DATE NULL;
